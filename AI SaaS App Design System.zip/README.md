
  # AI SaaS App Design System

  This is a code bundle for AI SaaS App Design System. The original project is available at https://www.figma.com/design/35xZhfoRDJ8qwov9TqwmP4/AI-SaaS-App-Design-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  